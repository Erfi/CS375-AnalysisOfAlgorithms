/*
 * This class will test all your code
 */
public class Driver {

	public static void main(String[] args) {
		
	}
}
